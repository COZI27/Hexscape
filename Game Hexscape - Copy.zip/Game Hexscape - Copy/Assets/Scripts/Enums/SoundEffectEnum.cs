public enum SoundEffectEnum
{
	Dig_Sound,
	ES_01,
	ES_02,
	ES_03,
	ES_04,
	ES_05,
	Ground_Hit_Thud,
	Level_Up_Sound,
	Player_Died_Sound,
	TileClick_01,
	TileClick_02,
}
